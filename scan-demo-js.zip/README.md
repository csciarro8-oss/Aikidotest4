# scan-demo-js
Intentionally vulnerable Node.js app for testing CodeQL, Dependabot (npm), and secret scanning. Never deploy.
Run `npm install --package-lock-only` before pushing so Dependabot gets a lockfile.
