# scan-demo-java
Intentionally vulnerable Java app for CodeQL (java-kotlin) and Dependabot (maven; log4j 2.14.1 is the Log4Shell version). Never deploy.
