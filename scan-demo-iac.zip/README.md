# scan-demo-iac
Insecure Dockerfile, Terraform, and GitHub Actions workflow for testing CodeQL (actions), Dependabot (docker / actions / terraform), and any IaC scanner you add (Trivy, Checkov, tfsec).
Never apply or run any of this. The workflow's issue trigger will execute if you open an issue, so keep the repo private.
